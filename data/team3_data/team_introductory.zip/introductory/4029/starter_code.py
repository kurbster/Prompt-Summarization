def search_substr(full_text, search_text, allow_overlap=True):
	