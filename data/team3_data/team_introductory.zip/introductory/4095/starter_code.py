def added_char(s1, s2):
	