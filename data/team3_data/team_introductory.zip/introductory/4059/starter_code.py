def switch_lights(a):
	