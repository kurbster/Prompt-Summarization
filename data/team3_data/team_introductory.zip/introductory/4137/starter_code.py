def is_square(n):
	