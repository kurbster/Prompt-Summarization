def count_positives_sum_negatives(arr):
	