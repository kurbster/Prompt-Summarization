def riders(stations, station_x):
	