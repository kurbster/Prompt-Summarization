def sc(s):
	