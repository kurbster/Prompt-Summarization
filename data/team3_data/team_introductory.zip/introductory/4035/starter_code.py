def substring_test(str1, str2):
	