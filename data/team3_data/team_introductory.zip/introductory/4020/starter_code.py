def validate_hello(greetings):
	