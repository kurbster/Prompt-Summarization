def first_tooth(array):
	