def score_hand(cards):
	