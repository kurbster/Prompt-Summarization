def penultimate(a):
	