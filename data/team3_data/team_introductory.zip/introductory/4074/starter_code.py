def between_extremes(numbers):
	