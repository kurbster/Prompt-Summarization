def reverse_bits(n):
	