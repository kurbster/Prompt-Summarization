def first_dup(s):
	