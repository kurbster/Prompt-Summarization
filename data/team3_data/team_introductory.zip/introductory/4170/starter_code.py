def super_sum(D, N):
	