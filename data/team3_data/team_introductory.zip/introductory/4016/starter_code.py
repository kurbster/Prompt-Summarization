def game(a, b):
	