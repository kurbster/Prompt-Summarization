def iq_test(numbers):
	