def elections_winners(votes, k):
	