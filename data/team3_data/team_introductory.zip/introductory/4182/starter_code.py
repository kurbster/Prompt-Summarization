def survivor(n):
	