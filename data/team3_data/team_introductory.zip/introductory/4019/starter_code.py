def max_multiple(divisor, bound):
	