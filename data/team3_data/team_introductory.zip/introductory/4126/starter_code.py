def what_time_is_it(angle):
	