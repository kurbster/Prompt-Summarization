def permutation_position(perm):
	