def sum_prod(strexpression):
	