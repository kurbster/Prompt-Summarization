def sillycase(silly):
	