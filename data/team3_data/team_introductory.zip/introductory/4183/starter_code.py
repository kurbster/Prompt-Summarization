def greatest_distance(arr):
	