def rec(x):
	