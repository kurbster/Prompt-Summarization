def no_repeat(string):
	