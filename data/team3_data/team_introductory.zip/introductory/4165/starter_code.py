def uni_total(string):
	