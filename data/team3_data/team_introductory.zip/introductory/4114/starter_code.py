def pagination_text(page_number, page_size, total_products):
	