def find_outlier(integers):
	