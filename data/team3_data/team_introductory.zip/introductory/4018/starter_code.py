def isDigit(string):
	