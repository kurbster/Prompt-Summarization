def count_correct_characters(correct, guess):
	