def counting_triangles(V):
	