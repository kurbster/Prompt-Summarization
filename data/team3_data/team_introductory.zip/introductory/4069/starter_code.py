def nth_fib(n):
	