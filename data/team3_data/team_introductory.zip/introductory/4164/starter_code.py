def first_non_repeating_letter(string):
	