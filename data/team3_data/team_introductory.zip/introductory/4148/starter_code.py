def sum_digits(number):
	