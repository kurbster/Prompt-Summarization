def string_to_array(s):
	