def get_free_urinals(urinals):
	