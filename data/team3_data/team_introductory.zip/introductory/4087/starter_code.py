def get_char(c):
	