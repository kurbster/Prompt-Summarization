def filter_list(l):
	