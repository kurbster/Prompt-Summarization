def number(lines):
	