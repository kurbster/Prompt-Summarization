def crossing_sum(matrix, row, col):
	