def cake_slice(n):
	