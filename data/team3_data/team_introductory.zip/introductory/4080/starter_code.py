def arr_check(arr):
	