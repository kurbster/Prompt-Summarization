def points(n):
	