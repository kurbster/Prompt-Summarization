def solution(number):
	