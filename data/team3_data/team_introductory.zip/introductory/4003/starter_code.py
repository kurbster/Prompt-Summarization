def possible_positions(pos):
	