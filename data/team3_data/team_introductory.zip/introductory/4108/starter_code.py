def sum_even_numbers(seq):
	