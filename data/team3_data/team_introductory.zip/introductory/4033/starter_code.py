def contamination(text, char):
	