class Solution:
    def possibleBipartition(self, N: int, dislikes: List[List[int]]) -> bool:
        