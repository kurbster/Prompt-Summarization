class Solution:
    def tallestBillboard(self, rods: List[int]) -> int:
        