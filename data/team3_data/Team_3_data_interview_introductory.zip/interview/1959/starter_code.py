class Solution:
    def champagneTower(self, poured: int, query_row: int, query_glass: int) -> float:
        