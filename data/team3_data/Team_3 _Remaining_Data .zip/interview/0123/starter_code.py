class Solution:
    def numMusicPlaylists(self, N: int, L: int, K: int) -> int:
        