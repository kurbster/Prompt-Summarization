class Solution:
    def numPoints(self, points: List[List[int]], r: int) -> int:
        