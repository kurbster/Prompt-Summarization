class Solution:
    def invalidTransactions(self, transactions: List[str]) -> List[str]:
        