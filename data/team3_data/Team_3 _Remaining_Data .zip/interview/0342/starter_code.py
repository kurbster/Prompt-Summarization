class Solution:
    def countBattleships(self, board: List[List[str]]) -> int:
        