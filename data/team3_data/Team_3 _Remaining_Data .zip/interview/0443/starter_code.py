class Solution:
    def numTeams(self, rating: List[int]) -> int:
        