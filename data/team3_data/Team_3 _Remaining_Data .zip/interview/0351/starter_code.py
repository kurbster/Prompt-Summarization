class Solution:
    def brokenCalc(self, X: int, Y: int) -> int:
        